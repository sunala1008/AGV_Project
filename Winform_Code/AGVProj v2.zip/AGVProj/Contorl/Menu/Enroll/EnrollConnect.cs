﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AGVProj
{
    public partial class EnrollTest : UserControl
    {
        public EnrollTest()
        {
            InitializeComponent();
        }

        private void Btnconnect_Click(object sender, EventArgs e)
        {
            MessageBox.Show("AVG 연결");

            OnConnectButtonClicked();
        }

        public void Connect_Click()
        {
            btnconnect.Click += new EventHandler(Btnconnect_Click);
        }

        #region ConnectButtonClicked event things for C# 3.0
        public event EventHandler<ConnectButtonClickedEventArgs> ConnectButtonClicked;

        protected virtual void OnConnectButtonClicked(ConnectButtonClickedEventArgs e)
        {
            if (ConnectButtonClicked != null)
                ConnectButtonClicked(this, e);
        }

        private ConnectButtonClickedEventArgs OnConnectButtonClicked()
        {
            ConnectButtonClickedEventArgs args = new ConnectButtonClickedEventArgs();
            OnConnectButtonClicked(args);

            return args;
        }

        /*private ConnectButtonClickedEventArgs OnConnectButtonClickedForOut()
        {
            ConnectButtonClickedEventArgs args = new ConnectButtonClickedEventArgs();
            OnConnectButtonClicked(args);

            return args;
        }*/

        public class ConnectButtonClickedEventArgs : EventArgs
        {


            /*public ConnectButtonClickedEventArgs()
            {
            }

            public ConnectButtonClickedEventArgs()
            {

            }*/
        }
        #endregion
    }
}
