﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AGVProj
{
    public partial class EnrollConnect : UserControl
    {
        public EnrollConnect()
        {
            InitializeComponent();
        }
    }
}
