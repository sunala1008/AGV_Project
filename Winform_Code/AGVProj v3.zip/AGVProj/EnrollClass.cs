﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AGVProj
{
    public class EnrollClass
    {
        public string agvName { get; set; }

        public string registerName { get; set; }

        public string aIP { get; set; }

        public string aPort { get; set; }

        public string cIP { get; set; }

        public string cPort { get; set; }

        public Image map { get; set; }



    }
}
