﻿namespace WA_Client_cs
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.chbEcho = new System.Windows.Forms.CheckBox();
      this.btnOpenLocal = new System.Windows.Forms.Button();
      this.txbUserName = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.txbPassword = new System.Windows.Forms.TextBox();
      this.btnDisconnect = new System.Windows.Forms.Button();
      this.btnConnect = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.txbInput1 = new System.Windows.Forms.TextBox();
      this.txbChatList = new System.Windows.Forms.TextBox();
      this.tmrRefreshClient = new System.Windows.Forms.Timer(this.components);
      this.label3 = new System.Windows.Forms.Label();
      this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
      this.txbInput2 = new System.Windows.Forms.TextBox();
      this.btn = new System.Windows.Forms.Button();
      this.label4 = new System.Windows.Forms.Label();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.chbEcho);
      this.groupBox1.Controls.Add(this.btnOpenLocal);
      this.groupBox1.Controls.Add(this.txbUserName);
      this.groupBox1.Controls.Add(this.label2);
      this.groupBox1.Controls.Add(this.txbPassword);
      this.groupBox1.Controls.Add(this.btnDisconnect);
      this.groupBox1.Controls.Add(this.btnConnect);
      this.groupBox1.Controls.Add(this.label1);
      this.groupBox1.Location = new System.Drawing.Point(12, 47);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(354, 100);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "접속 정보";
      // 
      // chbEcho
      // 
      this.chbEcho.AutoSize = true;
      this.chbEcho.Location = new System.Drawing.Point(276, 37);
      this.chbEcho.Name = "chbEcho";
      this.chbEcho.Size = new System.Drawing.Size(53, 16);
      this.chbEcho.TabIndex = 2;
      this.chbEcho.Text = "Echo";
      this.chbEcho.UseVisualStyleBackColor = true;
      // 
      // btnOpenLocal
      // 
      this.btnOpenLocal.Location = new System.Drawing.Point(230, 74);
      this.btnOpenLocal.Name = "btnOpenLocal";
      this.btnOpenLocal.Size = new System.Drawing.Size(75, 23);
      this.btnOpenLocal.TabIndex = 6;
      this.btnOpenLocal.Text = "Local";
      this.btnOpenLocal.UseVisualStyleBackColor = true;
      this.btnOpenLocal.Click += new System.EventHandler(this.btnOpenLocal_Click);
      // 
      // txbUserName
      // 
      this.txbUserName.Location = new System.Drawing.Point(74, 20);
      this.txbUserName.Name = "txbUserName";
      this.txbUserName.Size = new System.Drawing.Size(168, 21);
      this.txbUserName.TabIndex = 0;
      this.txbUserName.Text = "test";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(16, 26);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(45, 12);
      this.label2.TabIndex = 4;
      this.label2.Text = "아이디:";
      // 
      // txbPassword
      // 
      this.txbPassword.Location = new System.Drawing.Point(74, 47);
      this.txbPassword.Name = "txbPassword";
      this.txbPassword.PasswordChar = '*';
      this.txbPassword.Size = new System.Drawing.Size(168, 21);
      this.txbPassword.TabIndex = 1;
      this.txbPassword.Text = "test";
      // 
      // btnDisconnect
      // 
      this.btnDisconnect.Enabled = false;
      this.btnDisconnect.Location = new System.Drawing.Point(128, 71);
      this.btnDisconnect.Name = "btnDisconnect";
      this.btnDisconnect.Size = new System.Drawing.Size(96, 23);
      this.btnDisconnect.TabIndex = 4;
      this.btnDisconnect.Text = "끊기";
      this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
      // 
      // btnConnect
      // 
      this.btnConnect.Location = new System.Drawing.Point(18, 71);
      this.btnConnect.Name = "btnConnect";
      this.btnConnect.Size = new System.Drawing.Size(104, 23);
      this.btnConnect.TabIndex = 3;
      this.btnConnect.Text = "연결";
      this.btnConnect.Click += new System.EventHandler(this.btn_Connect_Click);
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 47);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(52, 21);
      this.label1.TabIndex = 0;
      this.label1.Text = "암호:";
      // 
      // txbInput1
      // 
      this.txbInput1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txbInput1.BackColor = System.Drawing.Color.GreenYellow;
      this.txbInput1.Font = new System.Drawing.Font("GulimChe", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
      this.txbInput1.Location = new System.Drawing.Point(12, 297);
      this.txbInput1.MaxLength = 16;
      this.txbInput1.Name = "txbInput1";
      this.txbInput1.Size = new System.Drawing.Size(224, 32);
      this.txbInput1.TabIndex = 2;
      this.txbInput1.Text = "12345678ABCDEFGH";
      this.txbInput1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbInput_KeyDown);
      // 
      // txbChatList
      // 
      this.txbChatList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txbChatList.Location = new System.Drawing.Point(12, 153);
      this.txbChatList.Multiline = true;
      this.txbChatList.Name = "txbChatList";
      this.txbChatList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txbChatList.Size = new System.Drawing.Size(354, 128);
      this.txbChatList.TabIndex = 1;
      // 
      // tmrRefreshClient
      // 
      this.tmrRefreshClient.Enabled = true;
      this.tmrRefreshClient.Interval = 200;
      this.tmrRefreshClient.Tick += new System.EventHandler(this.tmrRefreshClient_Tick);
      // 
      // label3
      // 
      this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(12, 284);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(113, 12);
      this.label3.TabIndex = 6;
      this.label3.Text = "LCD 에 출력할 내용";
      // 
      // txbInput2
      // 
      this.txbInput2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txbInput2.BackColor = System.Drawing.Color.GreenYellow;
      this.txbInput2.Font = new System.Drawing.Font("GulimChe", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
      this.txbInput2.Location = new System.Drawing.Point(12, 329);
      this.txbInput2.MaxLength = 16;
      this.txbInput2.Name = "txbInput2";
      this.txbInput2.Size = new System.Drawing.Size(224, 32);
      this.txbInput2.TabIndex = 2;
      this.txbInput2.Text = "abcdefgh12345678";
      this.txbInput2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbInput_KeyDown);
      // 
      // btn
      // 
      this.btn.Font = new System.Drawing.Font("GulimChe", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
      this.btn.Location = new System.Drawing.Point(258, 297);
      this.btn.Name = "btn";
      this.btn.Size = new System.Drawing.Size(108, 63);
      this.btn.TabIndex = 7;
      this.btn.Text = "전송";
      this.btn.UseVisualStyleBackColor = true;
      this.btn.Click += new System.EventHandler(this.btn_Click);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(12, 13);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(215, 24);
      this.label4.TabIndex = 8;
      this.label4.Text = "H-Server 를 이용하여 원격지의 LCD를\r\nTCP/IP 로 제어하는 예제입니다.";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(378, 368);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.btn);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.txbInput2);
      this.Controls.Add(this.txbInput1);
      this.Controls.Add(this.txbChatList);
      this.Name = "Form1";
      this.Text = "H-Server 용 클라이언트 - http://WhiteAT.com";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
      this.Load += new System.EventHandler(this.Form1_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.TextBox txbPassword;
    public System.Windows.Forms.Button btnDisconnect;
    private System.Windows.Forms.Button btnConnect;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox txbInput1;
    private System.Windows.Forms.TextBox txbChatList;
    private System.Windows.Forms.Timer tmrRefreshClient;
    private System.Windows.Forms.Label label3;
    public System.Windows.Forms.TextBox txbUserName;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Button btnOpenLocal;
    private System.Windows.Forms.ToolTip toolTip1;
    private System.Windows.Forms.CheckBox chbEcho;
    private System.Windows.Forms.TextBox txbInput2;
    private System.Windows.Forms.Button btn;
    private System.Windows.Forms.Label label4;
  }
}

