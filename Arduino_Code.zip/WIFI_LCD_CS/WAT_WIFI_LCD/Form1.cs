﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HServer;

namespace WA_Client_cs
{
  public partial class Form1 : Form
  {
    WATHClient client = null;

    public Form1()
    {
      InitializeComponent();
    }

    private void btnOpenLocal_Click(object sender, EventArgs e)
    {
      client = new WATHClient("127.0.0.1");
      client.IsUseEcho = this.chbEcho.Checked;
      client.eConnected += new E_Connected(client_eConnected);
      client.eDisconnected += new E_Disconnected(client_eDisconnected);
      client.eAddLog += new E_AddLog(client_eAddLog);
      if (client.Connect(this.txbUserName.Text,  this.txbPassword.Text))
      {
        UpdateControl(true);
        this.btnOpenLocal.Enabled = false;
      }
    }
     
    private void btn_Connect_Click(object sender, EventArgs e)
    {
      client = new WATHClient();
      client.IsUseEcho = this.chbEcho.Checked;
      client.eConnected += new E_Connected(client_eConnected);
      client.eDisconnected += new E_Disconnected(client_eDisconnected);
      client.eAddLog += new E_AddLog(client_eAddLog);
      if (client.Connect(this.txbUserName.Text, this.txbPassword.Text))
      {
        UpdateControl(true);
        this.btnOpenLocal.Enabled = false;
      }
    }

    void client_eAddLog(string s)
    {
      this.AddMessage(s);
    }

    void client_eConnected(System.Net.Sockets.TcpClient c)
    {
      this.AddMessage("## 서버에 접속 되었습니다.");
    }

    void client_eDisconnected(System.Net.Sockets.TcpClient c)
    {
      this.AddMessage("## 접속이 종료되었습니다.");
      if (client == null) return;
      if (client.strMsgs.Count > 0)
      {
        this.AddMessage(client.strMsgs[0]);
        client.strMsgs.RemoveAt(0);
      }
      this.UpdateControl(false);
    }

    private void btnDisconnect_Click(object sender, EventArgs e)
    {
      client.Stop();
      this.UpdateControl(false);
      this.btnOpenLocal.Enabled = true;
    }

    public void AddMessage(string msg)
    {

      txbChatList.AppendText(msg + "\r\n");
      txbChatList.ScrollToCaret();
      txbInput1.Focus();
    }

    private void txbInput_KeyDown(object sender, KeyEventArgs e)
    {
      if (string.IsNullOrEmpty(txbInput1.Text)) return;

      if (e.KeyCode == Keys.Enter)
      {
        client.sendOnlyText(txbInput1.Text);
        txbInput1.Text = "";
      }
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (client != null)
      {
        client.Stop();
      }
      client = null;
    }

    public void UpdateControl(bool _connect)
    {
      this.chbEcho.Enabled = !_connect;
      btnConnect.Enabled = !_connect;
      btnDisconnect.Enabled = _connect;
      txbInput1.Enabled = _connect;
    }

    private void tmrRefreshClient_Tick(object sender, EventArgs e)
    {
  
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      CheckForIllegalCrossThreadCalls = false;
    }

    private void btn_Click(object sender, EventArgs e)
    {
      client.sendOnlyText("1:" + txbInput1.Text + "2:" + txbInput2.Text);
    }
  }
}
